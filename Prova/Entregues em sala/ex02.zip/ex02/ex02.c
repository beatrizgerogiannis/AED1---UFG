#include "ex02.h"

No *aloca_No(){
    No *p = (No*)malloc(sizeof(No));
    p->prox = NULL;

    return p;
}

Lista *inicia_Lista(){
    Lista *lista;
    lista = (Lista*)malloc(sizeof(Lista));

    lista->inicio = NULL;
    lista->final = lista->inicio;

    return lista;
}

void compra_Carta(Lista *lista, int cor, int numero){
    No *p = aloca_No();

    p->carta.cor = cor;
    p->carta.valor = numero;

    if(lista->inicio == NULL){
        lista->inicio = p;
        lista->final = p;
    }else{
        p->prox = lista->inicio;
        lista->inicio = p;
    }
}
void mostrar_Cartas(Lista *lista){
    if(lista->inicio == NULL){
        printf("Nao tem nada na mao.\n");
    }else{
        No *aux = lista->inicio;
        int i=1;

        while(aux != NULL){
            printf("\nCarta %d", i);
            printf("\nCor: %d", aux->carta.cor);
            printf("\nNumero: %d", aux->carta.valor);
            aux = aux->prox;
            i++;
        }
    }
}

void jogar_Carta(Lista *lista){
    if(lista->inicio == NULL){
        printf("A mao esta vazia.\n");
    }else{
        No *aux = lista->inicio->prox;
        lista->inicio->prox = aux->prox;
        lista->inicio = aux;
    }
}