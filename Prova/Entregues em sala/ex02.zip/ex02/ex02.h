#include <stdio.h>
#include <stdlib.h>

typedef struct{
    int cor;
    int valor;
}Carta;

struct No{
    Carta carta;
    struct No *prox;
};
typedef struct No No;

typedef struct{
    No *inicio;
    No *final;
}Lista;


No *aloca_No();
Lista *inicia_Lista();
void compra_Carta(Lista *lista, int cor, int numero);
void mostrar_Cartas(Lista *lista);
void jogar_Carta(Lista *lista);