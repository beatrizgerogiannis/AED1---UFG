#include "ex02.h"

int main(){

    Lista *lista;

    lista = inicia_Lista();

    compra_Carta(lista, 1, 10);
    compra_Carta(lista, 2, 5);
    compra_Carta(lista, 3, 3);
    compra_Carta(lista, 4, 6);

    printf("\nAntes: ");
    mostrar_Cartas(lista);

    jogar_Carta(lista);
    jogar_Carta(lista);
    printf("\n\nDepois: ");
    mostrar_Cartas(lista);

    return 0;
}

