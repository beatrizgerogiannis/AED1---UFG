#include <stdio.h>
#include <stdlib.h>

#define MAX_CARTAS 10
#define INICIO 0

typedef struct{
    int cor;
    int numero;
}Carta_Uno;

typedef struct{
    Carta_Uno carta[MAX_CARTAS];
    int inicio;
    int final;
}Lista;

void inicia_Lista(Lista *lista);
void adiciona_Cartas(Lista *lista, int cor, int numero);
int tamanho_Lista(Lista lista);
int conta(Lista lista);
int conta_Cartas_Verdes(Lista lista);
void mostra_Cartas(Lista lista);