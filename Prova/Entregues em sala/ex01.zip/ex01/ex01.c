#include "ex01.h"
 

void inicia_Lista(Lista *lista){
    lista->inicio = INICIO;
    lista->final = lista->inicio;
}

void adiciona_Cartas(Lista *lista, int cor, int numero){
    
    if(lista->final > MAX_CARTAS){
        printf("A mao ja esta cheia.\n");
    }else{
        lista->carta[lista->final].cor = cor;
        lista->carta[lista->final].numero = numero;
        lista->final++;
    }
}

int tamanho_Lista(Lista lista){
    int tamanho=0;
    for(int i=lista.inicio; i<lista.final; i++){
        tamanho++;
    }
    return tamanho;
}

int conta_Cartas_Verdes(Lista lista){
    int cont=0;
    int tamanho = tamanho_Lista(lista);
    
    if(tamanho == 0){
        return cont;
    }else{
        if(lista.carta[lista.final].cor == 2){
            tamanho--;
            cont++;
            return conta_Cartas_Verdes(lista);
        }else{
            tamanho--;
            return conta_Cartas_Verdes(lista);
        }
    }
}

int conta(Lista lista){
    int cont=0;

    for(int i=lista.inicio; i<lista.final; i++){
        if(lista.carta[i].cor == 2){
            cont++;
        }
    }
    return cont;
}

void mostra_Cartas(Lista lista){
    for(int i=lista.inicio; i<lista.final; i++){
        printf("\nCor: %d", lista.carta[i].cor);
        printf("\nNumero: %d\n", lista.carta[i].numero);
    }   
}