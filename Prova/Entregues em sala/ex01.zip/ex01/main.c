#include "ex01.h"

int main(){

    Lista lista;
    Carta_Uno carta;
    int qtd_cartas_verdes;

    inicia_Lista(&lista);

    adiciona_Cartas(&lista, 1, 4);
    adiciona_Cartas(&lista, 2, 6);
    adiciona_Cartas(&lista, 4, 5);
    adiciona_Cartas(&lista, 3, 7);
    adiciona_Cartas(&lista, 2, 2);
    adiciona_Cartas(&lista, 1, 1);
    adiciona_Cartas(&lista, 3, 9);


    printf("Cartas: ");
    mostra_Cartas(lista);

    /*qtd_cartas_verdes = conta_Cartas_Verdes(lista);
    printf("%d", qtd_cartas_verdes);*/

    qtd_cartas_verdes = conta(lista);
    printf("Quantidade cartas verdes: %d", qtd_cartas_verdes);

    return 0;
}